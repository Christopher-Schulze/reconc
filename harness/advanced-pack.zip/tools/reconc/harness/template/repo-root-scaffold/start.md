# START - Project

You are an agent joining the Project repository. This file is the only onboarding entrypoint. It is read-only onboarding, not a setup script, not a task transition, and not permission to edit files.

## 1. Read In This Order

1. `AGENTS.md` - local repo rules, structure, TASK lifecycle, spec discipline, protected paths.
2. `docs/tasks.md` - persistent TASK logbook; read the `Current:` header. If it is not `Current: none`, verify it matches exactly one unchecked `[ ] TASK-NNNN-Name` row.
3. The current TASK detail file referenced from `Current:`, e.g. `docs/tasks/TASK-0001-Bootstrap-workflow-enforcement.md`. If `Current: none` has queued executable work, report that claim is required after onboarding. If no unchecked `[ ]` TASK exists, do not edit during onboarding; report that AGENTS.md Continuity Sweep is required.
4. `docs/documentation.md` - current codebase/workflow documentation.
5. `docs/spec.md` only when the active TASK requires spec/architecture context, and then only the relevant section plus dependencies unless the TASK/user asks for full-spec review.
6. `docs/decisions.md` only when rationale/tradeoff context is needed.
7. Referenced `research/...` files only when the active TASK/spec section points to them; `research/` stays read-only.
8. Do not read, list, search, summarize, or use `_drop/` during onboarding. `_drop/` is manual user/team intake and is only touched when the user explicitly names it for the current task.

## 2. Verify Guardrails

Run these read-only checks from the repo root after reading the files above:

- `reconc session-briefing . --json` (if `reconc` is not on PATH, use the
  repo-local binary matching your platform: `tools/reconc/dist/reconc-<os>-<arch>`,
  e.g. `tools/reconc/dist/reconc-linux-amd64`)

That single versioned response carries current TASK/Sub-Task, policy delta,
exact remediation, and durable repository-run state without a Git process or
repository write.

Do not run `reconc bootstrap`, `reconc init`, hook install, task promotion, claim assertion, or any file-writing command during onboarding.

## 3. Report Readiness And Wait

Send one chat message with:

- Current TASK name/description, Status summary, and next `[~]` Sub-Task.
- Files read.
- Reconc session-briefing result and `format_version`.
- Dirty worktree summary if visible.
- Open blockers or user-input needs from the current TASK. If no open `[ ]` TASK exists, state `Continuity Sweep required` and summarize whether all logbook rows are checked.

Then stop and wait for the user. No file writes, no claims, no task status changes, no commits during onboarding.

## 4. After The User Says Go

Follow `AGENTS.md`: read the task-relevant source/spec/research paths, edit surgically, update TASK notes/subtasks incrementally, flush `docs/documentation.md` only at real workflow boundaries, run relevant checks, and commit once per completed logical TASK unless the user explicitly says not to.

When autonomous execution is requested, the agent enables the durable switch
itself with `reconc run on .`, verifies it with `reconc run status .`, and
disables it with `reconc run off .` only on explicit user stop. A blocked TASK
releases the current Stop and automatically records `blocked_task`; do not
issue `run off` for a blocker. Resolve the blocker, then run `reconc run on .`
to resume. Never ask the user to operate these commands. The switch is scoped
to this repository. Claude Code, Codex, GitHub Copilot, Cursor, Devin CLI, Antigravity
CLI, and ZCode expose synchronous Stop continuation. Oh My Pi exposes awaited
main-session `session_stop` with an eight-continuation cap; Pi 1.x continues
natively at the awaited `agent_before_settle` boundary, while older Pi uses
inferred fail-open `agent_settled` continuation with no delivery
acknowledgement; OpenCode and Kilo
Code use best-effort, fail-open end-of-run adapters (`session.idle`, or
OpenCode 2.x execution events). It claims queued work when
`Current: none`, disables on complete or absent state after terminal gates,
releases blocked state to the hard Stop gate, and fails closed on invalid TASK
state. An interrupt or six repeated no-progress continuations releases only
the current invocation without changing the durable switch. Prompt text,
compaction, session boundaries, runtime changes, and application restarts never
mutate it; `run off` is the only manual disable action. Run control is not a parallel workflow:
keep TASK progress durable, write tests with code, commit once per completed
TASK, promote or claim the next executable TASK, never auto-push, and on
context limits persist exact progress in the TASK control plane. Explicit user
interrupt always stops the current invocation without changing durable run
state.

Grok Build has a native hard PreToolUse boundary. Reconc also emits exact Stop
block JSON in the normal TUI without a leader, but only an installed Grok guide
that advertises blocking Stop decision control proves synchronous enforcement.
User interrupts and session-end reasons release. Passive Stop distributions
can use optional leader fallback over the Unix socket or Windows named pipe; only
delivered interjections count toward the 32-attempt no-progress series, and
capability-proven native hosts suppress duplicate prompts. Managed activation
requires exact
hook/wrapper artifacts and route tokens. `reconc doctor --deep` reports native
Stop support and separately verifies protocol 1 plus `_x.ai/interject`.
